//THIS IS NOT THE HOME CLASS!
package com.slowpoke.minix;


import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Layout;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.azeesoft.lib.colorpicker.ColorPickerDialog;
import com.gkemon.XMLtoPDF.PdfGenerator;
import com.gkemon.XMLtoPDF.PdfGeneratorListener;
import com.slowpoke.minix.canvasUtils.MultiTouchListener;
import com.xiaopo.flying.sticker.BitmapStickerIcon;
import com.xiaopo.flying.sticker.DeleteIconEvent;
import com.xiaopo.flying.sticker.Sticker;
import com.xiaopo.flying.sticker.StickerView;
import com.xiaopo.flying.sticker.TextSticker;
import com.xiaopo.flying.sticker.ZoomIconEvent;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    /**
     * Defining values
     */

    private static final String TAG = MainActivity.class.getSimpleName();
    public static final int PERM_RQST_CODE = 110;
    private StickerView stickerView;
    private TextSticker sticker;
    private RelativeLayout diaLog;
    private EditText dialogValue;
    private String editText_value = " ";
    private LinearLayout canvas;
    RelativeLayout textEditor;
    ColorPickerDialog colorWheel;
    private Handler handler;
    private Runnable runnable;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /** * Finding views!!!!!    */

        //dialog box
        diaLog = findViewById(R.id.dialog_view);

        //this is for the dialog value(where we get the value editTexts)
        dialogValue = diaLog.findViewById(R.id.editText_Value);

        //this is the stickerView
        stickerView = findViewById(R.id.sticker_view);

        //finding canvas
        canvas = findViewById(R.id.canvas);

        /** * Attributes views!!!!!    */
        textEditor = findViewById(R.id.text_editor_layout);
        textEditor.setVisibility(View.INVISIBLE);


        /** * Assigning Views    */

        //this is to invisible the dialog view at first
        diaLog.setVisibility(View.INVISIBLE);

        //this is the colour of the canvas
        stickerView.setBackgroundColor(Color.WHITE);

        //color wheel
        colorWheel = ColorPickerDialog.createColorPickerDialog(this, ColorPickerDialog.DARK_THEME);


        /** * StickerView     */

        //currently you can config your own icons and icon event
        //the event you can custom
        BitmapStickerIcon deleteIcon = new BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_close_white_18dp),
                BitmapStickerIcon.LEFT_TOP);
        deleteIcon.setIconEvent(new DeleteIconEvent());

        BitmapStickerIcon zoomIcon = new BitmapStickerIcon(ContextCompat.getDrawable(this,
                com.xiaopo.flying.sticker.R.drawable.sticker_ic_scale_white_18dp),
                BitmapStickerIcon.RIGHT_BOTOM);
        zoomIcon.setIconEvent(new ZoomIconEvent());


        stickerView.setIcons(Arrays.asList(deleteIcon, zoomIcon));

        //default icon layout
        //stickerView.configDefaultIcons();

        /** * StickerView Sticker Operations    */
        stickerView.setOnStickerOperationListener(new StickerView.OnStickerOperationListener() {
            @Override
            public void onStickerAdded(@NonNull Sticker sticker) {
                Log.d(TAG, "onStickerAdded");
            }

            @Override
            public void onStickerClicked(@NonNull Sticker sticker) {

            }

            @Override
            public void onStickerDeleted(@NonNull Sticker sticker) {
                Log.d(TAG, "onStickerDeleted");
            }

            @Override
            public void onStickerDragFinished(@NonNull Sticker sticker) {
                Log.d(TAG, "onStickerDragFinished");

            }

            @Override
            public void onStickerTouchedDown(@NonNull Sticker sticker) {
                Log.d(TAG, "onStickerTouchedDown");

            }

            @Override
            public void onStickerZoomFinished(@NonNull Sticker sticker) {
                Log.d(TAG, "onStickerZoomFinished");
            }

            @Override
            public void onStickerFlipped(@NonNull Sticker sticker) {
                Log.d(TAG, "onStickerFlipped");

            }

            @Override
            public void onStickerDoubleTapped(@NonNull Sticker sticker) {
                openDialog(null);
            }
        });


        /** * Canvas! to make it movable, rotate-able, resize-able   */

        canvas.setOnTouchListener(new MultiTouchListener());


        /** * A handler to check whether sticker has been selected or not (for ediotr layout)   */
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                isTextSeleted();
                handler.post(runnable);
            }
        };
        handler.postDelayed(runnable,400);
    }


    private void loadSticker() {

        //will use as get from gallery later!
        Drawable drawable1 =
                ContextCompat.getDrawable(this, R.drawable.haizewang_23);
        //stickerView.addSticker(new DrawableSticker(drawable1), Sticker.Position.BOTTOM | Sticker.Position.RIGHT);

        stickerView.addSticker(
                new TextSticker(getApplicationContext())
                        .setText("loli")
                        .setMaxTextSize(50)
                        .resizeText()
                , Sticker.Position.TOP);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERM_RQST_CODE && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadSticker();
        }
    }


    public void testLock(View view) {
        stickerView.setLocked(!stickerView.isLocked());
    }

    public void testRemove(View view) {
        if (stickerView.removeCurrentSticker()) {
            Toast.makeText(MainActivity.this, "Remove current Sticker successfully!", Toast.LENGTH_SHORT)
                    .show();
        } else {
            Toast.makeText(MainActivity.this, "Remove current Sticker failed!", Toast.LENGTH_SHORT)
                    .show();
        }
    }


    public void reset(View view) {
        stickerView.removeAllStickers();
        loadSticker();
    }

    public void testAdd(View view) {

        sticker = new TextSticker(this);
        sticker.setText("New Text");
        sticker.setTextColor(Color.BLACK);
        sticker.setTextAlign(Layout.Alignment.ALIGN_CENTER);
        sticker.resizeText();

        stickerView.addSticker(sticker);

    }


    // for PDF
    public void PDF(View v) {
        stickerView.setLocked(true);
        PdfGenerator.getBuilder()
                .setContext(MainActivity.this)
                .fromViewIDSource()
                .fromViewID(MainActivity.this, R.id.sticker_view)
                .setFileName("BruhPDF")
                .setFolderNameOrPath("MyFolder/Documents/")
                .openPDAfterGeneration(true)
                .build(new PdfGeneratorListener() {
                    @Override
                    public void onStartPDFGeneration() {

                    }

                    @Override
                    public void onFinishPDFGeneration() {
                        stickerView.setLocked(false);
                    }


                });
    }


    public void changeText(View view) {
        dialogValue.onEditorAction(EditorInfo.IME_ACTION_DONE);
        editText_value = dialogValue.getText().toString();
        ((TextSticker) stickerView.getCurrentSticker()).setText(editText_value);
        sticker.resizeText();
        stickerView.replace(stickerView.getCurrentSticker());
        diaLog.setVisibility(View.INVISIBLE);
    }


    public void openColorWheel(View v) {
        colorWheel.show();
        colorWheel.setOnColorPickedListener((color, hexVal) -> {
            ((TextSticker) stickerView.getCurrentSticker()).setTextColor(color);
            stickerView.replace(stickerView.getCurrentSticker());
        });
    }

    @Override
    public void onBackPressed() {
        //LinearLayout linearLayout = findViewById(R.id.home_button);
        //linearLayout.setVisibility(View.VISIBLE);
        //colourView.setVisibility(View.INVISIBLE);
    }

    private void isTextSeleted() {

        if (stickerView.getCurrentSticker() == null) {
            //hide text editing components layout
            LinearLayout linearLayout = findViewById(R.id.home_layout);
            linearLayout.setVisibility(View.VISIBLE);
            textEditor.setVisibility(View.INVISIBLE);
            stickerView.invalidate();
        }

        else {
            //show the layout
            LinearLayout linearLayout = findViewById(R.id.home_layout);
            linearLayout.setVisibility(View.INVISIBLE);
            textEditor.setVisibility(View.VISIBLE);
        }
    }

    public void openDialog(View v){
        diaLog.setVisibility(View.VISIBLE);
        dialogValue.setText(((TextSticker) sticker).getText());
    }

    public void copy(View view){
        stickerView.addSticker(
                new TextSticker(getApplicationContext())
                        .setText(sticker.getText())
                        .setMaxTextSize(50)
                        .resizeText()
                , Sticker.Position.TOP);
    }
}
