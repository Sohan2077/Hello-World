package com.slowpoke.minix;

import androidx.appcompat.app.AppCompatActivity;

public class TextEditClass extends AppCompatActivity {
    
}
